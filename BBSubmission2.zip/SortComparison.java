import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

// -------------------------------------------------------------------------

/**
 *  This class contains static methods that implementing sorting of an array of numbers
 *  using different sort algorithms.
 *
 *  @author Dervla Brennan
 *  @version HT 2019
 */

class SortComparison {

	/**
	 * Sorts an array of doubles using InsertionSort.
	 * This method is static, thus it can be called as SortComparison.sort(a)
	 * @param a: An unsorted array of doubles.
	 * @return array sorted in ascending order.
	 *
	 */
	static double [] insertionSort (double a[])
	{

		double temp;
		for(int i = 1; i < a.length; i++)
		{
			for(int j = i; j > 0; j--)
			{
				if(a[j] < a[j-1])
				{
					temp = a[j];
					a[j] = a[j-1];
					a[j-1] = temp;
				}
			}
		}
		return a;

	}//end insertionsort

	/**
	 * Sorts an array of doubles using Quick Sort.
	 * This method is static, thus it can be called as SortComparison.sort(a)
	 * @param a: An unsorted array of doubles.
	 * @return array sorted in ascending order
	 *
	 */

	static double [] quickSort (double a[])
	{
		qSort(a, 0, a.length-1);
		return a;
	}

	private static void qSort (double a[], int lo, int hi)
	{
		if(lo >= hi)
		{
			return;
		}
		//get pivot val
		int mid = lo + (hi - lo)/2;
		double pivot = a[mid];

		int i = lo;
		int j = hi;

		while (i <= j)
		{
			while(a[i] < pivot)
			{
				i++;
			}
			while(a[j] > pivot)
			{
				j--;
			}
			if(i <= j)
			{
				double temp = a[i];
				a[i] = a[j];
				a[j] = temp;
				i++;
				j--;
			}
		}
		//recursively sort the two partitions
		if(lo < j)
		{
			qSort(a, lo, j);
		}
		if(hi > i)
		{
			qSort(a, i, hi);
		}
	}//end quicksort
	
	/**
	 * Sorts an array of doubles using Merge Sort.
	 * This method is static, thus it can be called as SortComparison.sort(a)
	 * @param a: An unsorted array of doubles.
	 * @return array sorted in ascending order
	 *
	 */
	/**
	 * Sorts an array of doubles using iterative implementation of Merge Sort.
	 * This method is static, thus it can be called as SortComparison.sort(a)
	 *
	 * @param a: An unsorted array of doubles.
	 * @return after the method returns, the array must be in ascending sorted order.
	 */
	//bottom up
	static double[] mergeSortIterative (double a[]) 
	{

		double [] auxiliary = new double[a.length];
		for(int i = 1; i < a.length; i = i+i)
		{
			for(int j = 0; j < a.length - i; j += i+i)
			{
				merge(a, auxiliary, j, j+i-1, Math.min(j+i+i-1, a.length-1));
			}
		}
		return a;
	}//end mergesortIterative

	/**
	 * Sorts an array of doubles using recursive implementation of Merge Sort.
	 * This method is static, thus it can be called as SortComparison.sort(a)
	 *
	 * @param a: An unsorted array of doubles.
	 * @return after the method returns, the array must be in ascending sorted order.
	 */
	//top down
	static double[] mergeSortRecursive (double a[]) 
	{

		double [] aux = new double[a.length];
		msort(a, aux, 0, a.length - 1);
		return a;

	}//end mergeSortRecursive

	private static void msort(double [] a, double [] aux, int lo, int hi)
	{
		if(hi <= lo) return;
		int mid = lo + (hi - lo)/2;
		msort(a, aux, lo, mid);
		msort(a, aux, mid + 1, hi);
		merge(a, aux, lo, mid, hi);
	}

	private static void merge(double [] a, double[] aux, int lo, int mid, int hi)
	{
		for(int k = lo; k <= hi; k++)
		{
			aux[k] = a[k];
		}
		int i = lo, j = mid + 1;
		for(int k = lo; k <= hi; k++)
		{
			if(i > mid)
			{
				a[k] = aux[j++];
			}
			else if(j > hi)
			{
				a[k] = aux[i++];
			}
			else if(aux[j] < aux[i])
			{
				a[k] = aux[j++];
			}
			else
			{
				a[k] = aux[i++];
			}
		}
	} //end merge sort


	/**
	 * Sorts an array of doubles using Selection Sort.
	 * This method is static, thus it can be called as SortComparison.sort(a)
	 * @param a: An unsorted array of doubles.
	 * @return array sorted in ascending order
	 *
	 */
	static double [] selectionSort (double a[])
	{

		for (int i = 0; i < a.length-1; i++)
		{
			int min = i;
			for (int j = i + 1; j < a.length; j++)
			{
				if(a[j] < a[min])
				{
					min = j;
				}
			}
			double temp = a[min];
			a[min] = a[i];
			a[i] = temp;
		}
		return a;


	}//end selectionsort


	/** NOTE: main methods have been commented out so as to not impact code coverage score */

	/*
    public static void main(String[] args)
    {
    	String [] files = {"src/numbers10.txt", "src/numbers100.txt", "src/numbers1000.txt", "src/numbers1000Duplicates.txt",
    							"src/numbersNearlyOrdered1000.txt", "src/numbersReverse1000.txt", "src/numbersSorted1000.txt"};
    	SortComparisonTest.main(files); 
    } 

    static double [] readFile(String url, int length)
    {
    	double[] numberArray = new double [length];
    	try
		{
			FileReader fileReader = new FileReader(url);
			BufferedReader bufferedReader = new BufferedReader(fileReader);
			boolean endOfFile = false;
			int i = 0;
			while(!endOfFile)
			{
				String numberData = bufferedReader.readLine();
				if(numberData == null)
				{
					endOfFile = true;
				}
				else
				{ 
					numberArray[i] = Double.parseDouble(numberData);
					i++;
				}
			}
		}
		catch(FileNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return numberArray;
    }

    static int elemsInFile(String url)
    {
    	int count = 0;
    	try
    	{
    		FileReader fileReader = new FileReader(url);
    		BufferedReader bufferedReader = new BufferedReader(fileReader);
    		boolean endOfFile = false;
    		while(!endOfFile)
    		{
    			if(bufferedReader.readLine() == null)
    			{
    				endOfFile = true;
    			}
    			else
    			{ 
    				count++;
    			}
    		}
    	}
    	catch(FileNotFoundException e)
    	{
    		e.printStackTrace();
    	}
    	catch(IOException e)
    	{
    		e.printStackTrace();
    	}
    	return count;
    }  */

}//end class

