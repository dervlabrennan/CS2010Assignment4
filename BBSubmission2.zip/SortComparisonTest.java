import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

//-------------------------------------------------------------------------
/**
 *  Test class for SortComparison.java
 *
 *  @author Dervla Brennan
 *  @version HT 2019
 *  
 *  							Insert			 Quick			Merge 			 Merge			Selection
 *  														  Recursive		   Iterative			
 *  10 random			    |	0.0058ms   |  0.0094ms    |	 0.0107ms	  |	   0.0108ms	    |	0.0057ms    |
 *  100 random			    |   0.0094ms   |  0.0108ms	  |	 0.3135ms	  |	   0.1878ms	    |	0.4018ms	|
 *  1000 random			    |	7.5089ms   |  0.3412ms	  |	 0.2802ms	  |	   0.4896ms	    |	5.7926ms	|
 *  1000 few unique		    |	1.3861ms   |  0.1345ms	  |	 0.1722ms	  |	   0.2408ms	    |	0.6931ms	|
 *  1000 nearly ordered     |	0.9537ms   |  0.0805ms	  |	 0.1556ms	  |	   0.2419ms	    |	0.9366ms    |
 *  1000 reverse order      |	1.5764ms   |  0.0408ms	  |  0.1142ms	  |	   0.2336ms		|	0.8281ms	|
 *  1000 sorted			    |	1.3720ms   |  0.0495ms	  |	 0.2426ms	  |	   0.3946ms		|	1.3162ms	|
 *  
   
  
    a. Which of the sorting algorithms does the order of input have an impact on? Why?
   
   		All of the sorting algorithms are impacted by the order of input, indicated by the difference in runtime between 1000reverseorder.txt
   		and 1000sorted.txt. This is because more steps are required to sort data that is less ordered. 
 
	b. Which algorithm has the biggest difference between the best and worst performance, based
		on the type of input, for the input of size 1000? Why?
		
		Selection sort has the biggest difference between best and worst performance because the order of growth for 
		selection sort is O(N^2) in all cases
		
	c. Which algorithm has the best/worst scalability, i.e., the difference in performance time
		based on the input size? Please consider only input files with random order for this answer.
		
		Best: Merge sort recursive
		Worst: Insertion sort
		
	d. Did you observe any difference between iterative and recursive implementations of merge sort?
		
		Merge sort iterative took longer than merge sort recursive in each of the files - particularly when the data set was bigger and 
		random
		
	e. Which algorithm is the fastest for each of the 7 input files? 
	
		numbers10 - Selection sort
		numbers100 - Insertion sort
		numbers1000 - Merge sort recursive
		numbers1000Duplicates - Quick sort
		numbers1000NearlyOrdered - Quick sort
		numbers1000ReverseOrder - Quick sort
		numbers1000Sorted - Quick sort
		
 */
@RunWith(JUnit4.class)
public class SortComparisonTest
{
    //~ Constructor ........................................................
    @Test
    public void testConstructor()
    {
        new SortComparison();
    }

    //~ Public Methods ........................................................

    // ----------------------------------------------------------
    /**
     * Check that the methods work for empty arrays
     */
    @Test
    public void testEmpty()
    {
    	double[]array = new double[0];
    	assertEquals(array, SortComparison.insertionSort(array));
    	assertEquals(array, SortComparison.quickSort(array));
    	assertEquals(array, SortComparison.mergeSortIterative(array));
    	assertEquals(array, SortComparison.mergeSortRecursive(array));
    	assertEquals(array, SortComparison.selectionSort(array));
    }


    // TODO: add more tests here. Each line of code and each decision in Collinear.java should
    // be executed at least once from at least one test.
    
    @Test
    public void testInsertion()
    {
    	double [] array = {3,2,1};
    	double [] expResult = {1,2,3};
    	assertTrue(Arrays.equals(expResult, SortComparison.insertionSort(array)));
    	
    	double [] array2 = {4,5,1,7,2,1};
    	double [] expResult2 = {1,1,2,4,5,7};
    	assertTrue(Arrays.equals(expResult2, SortComparison.insertionSort(array2)));
    }
    
    @Test
    public void testQuick()
    {
    	double [] array = {3,2,1};
    	double [] expResult = {1,2,3};
    	assertTrue(Arrays.equals(expResult, SortComparison.quickSort(array)));
    	
    	double [] array2 = {4,5,1,7,2,1,15,9};
    	double [] expResult2 = {1,1,2,4,5,7,9,15};
    	assertTrue(Arrays.equals(expResult2, SortComparison.quickSort(array2)));
    }
    
    @Test
    public void testMergeIterative()
    {
    	double [] array = {3,2,1};
    	double [] expResult = {1,2,3};
    	assertTrue(Arrays.equals(expResult, SortComparison.mergeSortIterative(array)));
    	
    	double [] array2 = {4,5,1,7,2,1};
    	double [] expResult2 = {1,1,2,4,5,7};
    	assertTrue(Arrays.equals(expResult2, SortComparison.mergeSortIterative(array2)));
    }
    
    @Test
    public void testMergeRecursive()
    {
    	double [] array = {3,2,1};
    	double [] expResult = {1,2,3};
    	assertTrue(Arrays.equals(expResult, SortComparison.mergeSortRecursive(array)));
    	
    	double [] array2 = {4,5,1,7,2,1};
    	double [] expResult2 = {1,1,2,4,5,7};
    	assertTrue(Arrays.equals(expResult2, SortComparison.mergeSortRecursive(array2)));
    }
    
    @Test
    public void testSelection()
    {
    	double [] array = {3,2,1};
    	double [] expResult = {1,2,3};
    	assertTrue(Arrays.equals(expResult, SortComparison.selectionSort(array)));
    	
    	double [] array2 = {4,5,1,7,2,1};
    	double [] expResult2 = {1,1,2,4,5,7};
    	assertTrue(Arrays.equals(expResult2, SortComparison.selectionSort(array2)));
    }


    // NOTE: main methods have been commented out so as to not impact code coverage score
    // ----------------------------------------------------------
    /**
     *  Main Method.
     *  Use this main method to create the experiments needed to answer the experimental performance questions of this assignment.
     *
     */
    
  /*
   public static void main(String[] args)
    {
	   for(int i = 0; i < args.length; i++)
	   {
		   int size = SortComparison.elemsInFile(args[i]);
		   double[] testArray = new double[size];
		   double start, end, duration;
		   double total = 0;
		   
		   System.out.println((i + 1) + ". " + args[i]);
		   for(int j = 0; j < 3; j++)
		   {
			   testArray = SortComparison.readFile(args[i], size);
			   start = System.nanoTime();
		       SortComparison.insertionSort(testArray);
		       end = System.nanoTime();
		       duration = (end - start) * (Math.pow(10, -6));
		       total += duration;
		   }
		   System.out.println("Insertion average time = " + (total/3) + " ms");
		   
		   total = 0;
		   for(int j = 0; j < 3; j++)
		   {
			   testArray = SortComparison.readFile(args[i], size);
			   start = System.nanoTime();
		       SortComparison.quickSort(testArray);
		       end = System.nanoTime();
		       duration = (end - start) * (Math.pow(10, -6));
		       //System.out.println("Time taken for insertion sort = " + duration + " ms");  
		       total += duration;
		   }
		   System.out.println("Quick Average time = " + (total/3) + " ms");
	       
		   total = 0;
		   for(int j = 0; j < 3; j++)
		   {
			   testArray = SortComparison.readFile(args[i], size);
			   start = System.nanoTime();
		       SortComparison.mergeSortRecursive(testArray);
		       end = System.nanoTime();
		       duration = (end - start) * (Math.pow(10, -6)); 
		       total += duration;
		   }
		   System.out.println("Merge recursive average time = " + (total/3) + " ms");
		   
		   total = 0;
		   for(int j = 0; j < 3; j++)
		   {
			   testArray = SortComparison.readFile(args[i], size);
			   start = System.nanoTime();
		       SortComparison.mergeSortIterative(testArray);
		       end = System.nanoTime();
		       duration = (end - start) * (Math.pow(10, -6)); 
		       total += duration;
		   }
		   System.out.println("Merge iterative average time = " + (total/3) + " ms");
		   
		   total = 0;
		   for(int j = 0; j < 3; j++)
		   {
			   testArray = SortComparison.readFile(args[i], size);
			   start = System.nanoTime();
		       SortComparison.selectionSort(testArray);
		       end = System.nanoTime();
		       duration = (end - start) * (Math.pow(10, -6)); 
		       total += duration;
		   }
		   System.out.println("Selection average time = " + (total/3) + " ms\n");
	   }
	} 
   */
   
}

